@echo off
setlocal
cd /d "%~dp0ClashCraft"
if not exist "gradlew.bat" (
  echo ERRO: pasta ClashCraft nao encontrada ao lado deste arquivo.
  pause
  exit /b 1
)
echo Compilando o ClashCraft para NeoForge 1.21.1...
call gradlew.bat build --no-daemon
if errorlevel 1 (
  echo.
  echo A compilacao falhou. Veja o erro mostrado acima.
  echo Necessario: JDK 21 e acesso a internet para baixar as dependencias.
  pause
  exit /b 1
)
if not exist "build\libs\clashcraft-0.1.0-alpha.jar" (
  echo ERRO: O arquivo JAR esperado nao foi gerado.
  pause
  exit /b 1
)
copy /Y "build\libs\clashcraft-0.1.0-alpha.jar" "%~dp0ClashCraft.jar" >nul
echo.
echo Sucesso: ClashCraft.jar criado na mesma pasta deste script.
echo Coloque-o na pasta mods de Minecraft Java 1.21.1 com NeoForge.
pause
