# ClashCraft — estado de desenvolvimento

Versão: 0.1.0-alpha. Reconstrução em andamento após perda do ambiente temporário.
A autorização atual é continuar todas as tarefas sem aguardar "próxima".
O projeto NÃO está concluído em relação às tarefas T00–T28 do documento mestre.

Código reconstruído: dados JSON, validação, persistência, rede, combate no servidor,
combos, defesa, recursos, voo, status, projéteis, feixes, transformações, modelos
GeckoLib, HUD, seleção, duelos básicos, treino, missões básicas e restauração de blocos.
Conteúdo: 12 lutadores, 120 golpes, 12 transformações, 8 interações, 3 missões.
Assets são placeholders. Mecânicas exclusivas e parte da experiência visual ainda
precisam de implementação. Cliente e multiplayer ainda não foram validados.

Dependências fixadas: Minecraft 1.21.1, NeoForge 21.1.265, JDK 21,
Gradle 9.2.1, ModDevGradle 2.0.148, GeckoLib 4.9.3.

Este checkpoint foi salvo antes de concluir a nova compilação e os testes.
Não reutilizar os resultados da sessão anterior como prova desta reconstrução.
