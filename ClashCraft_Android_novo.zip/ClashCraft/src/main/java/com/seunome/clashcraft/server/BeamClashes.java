package com.seunome.clashcraft.server;
import com.google.gson.JsonObject;
import com.seunome.clashcraft.core.FighterData;
import java.util.*;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import static com.seunome.clashcraft.core.Definitions.*;
public final class BeamClashes {
    private static final List<Clash> clashes=new ArrayList<>();
    private static final class Clash {UUID a,b;int scoreA,scoreB,countA,countB,remaining=100;long inputTick=-1;Clash(ServerPlayer a,ServerPlayer b){this.a=a.getUUID();this.b=b.getUUID();}}
    public static boolean contains(ServerPlayer p){return clashes.stream().anyMatch(c->c.a.equals(p.getUUID())||c.b.equals(p.getUUID()));}
    public static boolean input(ServerPlayer p,Input input,long now){for(Clash c:clashes)if(c.a.equals(p.getUUID())||c.b.equals(p.getUUID())){if(input!=Input.LIGHT)return true;if(c.inputTick!=now){c.inputTick=now;c.countA=0;c.countB=0;}if(c.a.equals(p.getUUID())){if(c.countA++<2)c.scoreA++;}else if(c.countB++<2)c.scoreB++;return true;}return false;}
    private static boolean beam(ServerPlayer p){FighterData d=GameServer.data(p);Move m=GameServer.content.moves.get(d.move);return p.isAlive()&&d.enabled&&d.health>0&&m!=null&&m.type()==MoveType.beam&&m.frames().activeAt(d.tick);}
    private static boolean defined(ServerPlayer a,ServerPlayer b){Set<String> ids=new HashSet<>(List.of(GameServer.data(a).fighter,GameServer.data(b).fighter));for(JsonObject j:GameServer.content.interactions.values())if(text(j,"type","").equals("beam_clash")&&ids.containsAll(strings(j,"participants")))return true;return false;}
    public static void tick(MinecraftServer server){Iterator<Clash> it=clashes.iterator();while(it.hasNext()){Clash c=it.next();ServerPlayer a=server.getPlayerList().getPlayer(c.a),b=server.getPlayerList().getPlayer(c.b);if(a==null||b==null||a.level()!=b.level()||!beam(a)||!beam(b)||a.distanceToSqr(b)>1024){finish(a);finish(b);it.remove();continue;}FighterData ad=GameServer.data(a),bd=GameServer.data(b);ad.state=bd.state="CHARGING";ad.clashScore=c.scoreA-c.scoreB;bd.clashScore=-ad.clashScore;Vec3 mid=a.getEyePosition().add(b.getEyePosition()).scale(.5);a.serverLevel().sendParticles(ParticleTypes.ELECTRIC_SPARK,mid.x,mid.y,mid.z,5,.5,.5,.5,.1);if(--c.remaining<=0||Math.abs(c.scoreA-c.scoreB)>=20){if(c.scoreA!=c.scoreB)GameServer.clashHit(c.scoreA>c.scoreB?a:b,c.scoreA>c.scoreB?b:a);finish(a);finish(b);it.remove();}}
        List<ServerPlayer> players=server.getPlayerList().getPlayers();for(int i=0;i<players.size();i++){ServerPlayer a=players.get(i);if(contains(a)||!beam(a))continue;for(int j=i+1;j<players.size();j++){ServerPlayer b=players.get(j);if(contains(b)||!beam(b)||a.level()!=b.level()||a.distanceToSqr(b)>400||!Modes.canHit(a,b)||!defined(a,b))continue;Vec3 dir=b.getEyePosition().subtract(a.getEyePosition()).normalize();if(a.getLookAngle().dot(dir)<.9||b.getLookAngle().dot(dir.scale(-1))<.9||!a.hasLineOfSight(b))continue;clashes.add(new Clash(a,b));GameServer.data(a).state=GameServer.data(b).state="CHARGING";a.sendSystemMessage(Component.literal("Choque de feixes! Pressione ataque leve."));b.sendSystemMessage(Component.literal("Choque de feixes! Pressione ataque leve."));break;}}
    }
    private static void finish(ServerPlayer p){if(p==null)return;FighterData d=GameServer.data(p);d.move="";d.state=d.health<=0?"KO":d.stun>0?"HITSTUN":"IDLE";d.clashScore=0;d.tick=0;}
    public static void clear(){clashes.clear();}
    private BeamClashes(){}
}
