package com.seunome.clashcraft;

import com.mojang.logging.LogUtils;
import com.seunome.clashcraft.config.Settings;
import com.seunome.clashcraft.network.Packets;
import com.seunome.clashcraft.server.GameServer;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.Item;
import org.slf4j.Logger;

@Mod(ClashCraft.ID)
public final class ClashCraft {
    public static final String ID="clashcraft";
    public static final Logger LOG=LogUtils.getLogger();
    public static final DeferredRegister<Item> ITEMS=DeferredRegister.create(Registries.ITEM,ID);
    public ClashCraft(IEventBus bus,ModContainer container){ITEMS.register(bus);bus.addListener(Packets::register);container.registerConfig(ModConfig.Type.COMMON,Settings.SPEC);NeoForge.EVENT_BUS.register(GameServer.class);LOG.info("ClashCraft: servidor autoritativo carregado.");}
}
