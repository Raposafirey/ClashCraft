package com.seunome.clashcraft.server;
import com.google.gson.*;
import com.seunome.clashcraft.ClashCraft;
import com.seunome.clashcraft.core.Content;
import java.io.Reader;
import java.util.*;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
public final class ContentLoader extends SimplePreparableReloadListener<ContentLoader.Loaded> {
    public record Loaded(Content content,List<String> errors){}
    @Override protected Loaded prepare(ResourceManager manager,ProfilerFiller profiler){Map<String,JsonObject> files=new LinkedHashMap<>();List<String> errors=new ArrayList<>();for(String folder:List.of("fighters","moves","transformations","interactions","arenas","missions"))manager.listResources(folder,id->id.getPath().endsWith(".json")).forEach((id,r)->{try(Reader reader=r.openAsReader()){char[] buffer=new char[24001];int n=0,read;while(n<buffer.length&&(read=reader.read(buffer,n,buffer.length-n))>0)n+=read;if(n==buffer.length)throw new IllegalArgumentException("arquivo excede 24000 caracteres");JsonObject j=JsonParser.parseString(new String(buffer,0,n)).getAsJsonObject();String name=id.getPath().substring(folder.length()+1,id.getPath().length()-5);files.put(folder+"/"+id.getNamespace()+":"+name,j);}catch(Exception ex){errors.add(id+" | "+ex.getMessage());}});Content c=new Content(files);errors.addAll(c.errors);return new Loaded(c,List.copyOf(errors));}
    @Override protected void apply(Loaded result,ResourceManager manager,ProfilerFiller profiler){GameServer.content=result.content();GameServer.loadErrors=result.errors();GameServer.contentRevision++;result.errors().forEach(e->ClashCraft.LOG.error("ClashCraft JSON: {}",e));ClashCraft.LOG.info("ClashCraft: {} lutadores, {} golpes; {} erros",result.content().fighters.size(),result.content().moves.size(),result.errors().size());}
}
