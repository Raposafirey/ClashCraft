package com.seunome.clashcraft.server;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.*;
import com.seunome.clashcraft.core.*;
import com.seunome.clashcraft.config.Settings;
import java.util.*;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import static net.minecraft.commands.Commands.*;
import static com.seunome.clashcraft.core.Definitions.*;
public final class Commands {
    private static int reply(CommandSourceStack s,String text){s.sendSuccess(()->Component.literal(text),false);return 1;}
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher){
        dispatcher.register(literal("fighter").executes(c->reply(c.getSource(),"ClashCraft: list, info, select, data, validate, training, infinite, reset, mission, stats, ranking"))
            .then(literal("list").executes(c->reply(c.getSource(),String.join(", ",GameServer.content.fighters.keySet()))))
            .then(literal("select").then(argument("id",StringArgumentType.word()).suggests((c,b)->SharedSuggestionProvider.suggest(GameServer.content.fighters.keySet(),b)).executes(c->reply(c.getSource(),GameServer.select(c.getSource().getPlayerOrException(),StringArgumentType.getString(c,"id"))?"Lutador selecionado.":"Seleção recusada: ID, desbloqueio ou partida."))))
            .then(literal("info").then(argument("id",StringArgumentType.word()).suggests((c,b)->SharedSuggestionProvider.suggest(GameServer.content.fighters.keySet(),b)).executes(c->{Fighter f=GameServer.content.fighters.get(StringArgumentType.getString(c,"id"));return reply(c.getSource(),f==null?"ID desconhecido":f.name()+" | HP "+f.maxHealth()+" | energia "+f.maxEnergy()+" | "+f.archetype());})))
            .then(literal("data").executes(c->reply(c.getSource(),JSON.toJson(GameServer.data(c.getSource().getPlayerOrException())))))
            .then(literal("validate").requires(s->s.hasPermission(2)).executes(c->reply(c.getSource(),GameServer.loadErrors.isEmpty()?"Validação OK: "+GameServer.content.fighters.size()+" lutadores, "+GameServer.content.moves.size()+" golpes.":String.join("\n",GameServer.loadErrors))))
            .then(literal("reload").requires(s->s.hasPermission(2)).executes(c->{c.getSource().getServer().getCommands().performPrefixedCommand(c.getSource(),"reload");return 1;}))
            .then(literal("training").executes(c->{Modes.training(c.getSource().getPlayerOrException(),"idle");return reply(c.getSource(),"Treino ativo. /fighter infinite | /fighter reset");}).then(argument("mode",StringArgumentType.word()).suggests((c,b)->SharedSuggestionProvider.suggest(List.of("idle","guard","counter"),b)).executes(c->{String mode=StringArgumentType.getString(c,"mode");if(!Set.of("idle","guard","counter").contains(mode))return 0;Modes.training(c.getSource().getPlayerOrException(),mode);return 1;})))
            .then(literal("infinite").executes(c->{ServerPlayer p=c.getSource().getPlayerOrException();FighterData d=GameServer.data(p);if(!d.training||Modes.inMatch(p))return reply(c.getSource(),"Disponível somente em treino.");d.infinite=!d.infinite;return reply(c.getSource(),"Recursos infinitos: "+d.infinite);}))
            .then(literal("reset").executes(c->{ServerPlayer p=c.getSource().getPlayerOrException();if(Modes.inMatch(p))return 0;FighterData d=GameServer.data(p);Fighter f=GameServer.content.fighters.get(d.fighter);if(f==null)return 0;boolean training=d.training;GameServer.releaseMovement(p);d.select(f);d.training=training;return reply(c.getSource(),"Lutador restaurado.");}))
            .then(literal("mission").executes(c->reply(c.getSource(),String.join(", ",GameServer.content.missions.keySet()))).then(argument("id",StringArgumentType.word()).suggests((c,b)->SharedSuggestionProvider.suggest(GameServer.content.missions.keySet(),b)).executes(c->reply(c.getSource(),Modes.mission(c.getSource().getPlayerOrException(),StringArgumentType.getString(c,"id"))?"Missão iniciada.":"Não foi possível iniciar."))))
            .then(literal("stats").executes(c->{FighterData d=GameServer.data(c.getSource().getPlayerOrException());return reply(c.getSource(),"Vitórias "+d.wins+" | derrotas "+d.losses+" | combo máximo "+d.maxCombo+" | dano "+Math.round(d.totalDamage)+" | moedas "+d.coins);}))
            .then(literal("ranking").executes(c->{List<ServerPlayer> ps=new ArrayList<>(c.getSource().getServer().getPlayerList().getPlayers());ps.sort(Comparator.comparingInt((ServerPlayer p)->GameServer.data(p).wins).reversed());return reply(c.getSource(),"Jogadores conectados:\n"+String.join("\n",ps.stream().map(p->p.getGameProfile().getName()+": "+GameServer.data(p).wins).toList()));}))
            .then(literal("status").requires(s->s.hasPermission(2)).then(argument("player",EntityArgument.player()).then(argument("id",StringArgumentType.word()).then(argument("ticks",IntegerArgumentType.integer(1,12000)).executes(c->{String id=StringArgumentType.getString(c,"id");if(!Set.of("clashcraft:stun","clashcraft:burn","clashcraft:freeze","clashcraft:bleed","clashcraft:silence","clashcraft:slow","clashcraft:weakness").contains(id))return 0;GameServer.data(EntityArgument.getPlayer(c,"player")).statuses.put(id,IntegerArgumentType.getInteger(c,"ticks"));return reply(c.getSource(),"Status aplicado.");})))))
            .then(literal("debug").requires(s->s.hasPermission(2)).executes(c->{Settings.DEBUG.set(!Settings.DEBUG.get());return reply(c.getSource(),"Logs debug: "+Settings.DEBUG.get());}))
            .then(literal("balance").requires(s->s.hasPermission(2)).then(argument("damage",DoubleArgumentType.doubleArg(.1,10)).executes(c->{Settings.DAMAGE.set(DoubleArgumentType.getDouble(c,"damage"));return reply(c.getSource(),"Dano atualizado.");})))
            .then(literal("hub").requires(s->s.hasPermission(2)).executes(c->{Modes.hub(c.getSource().getPlayerOrException());return reply(c.getSource(),"Plataforma e indicações criadas.");})));
        dispatcher.register(literal("arena").requires(s->s.hasPermission(2)).then(literal("list").executes(c->reply(c.getSource(),String.join(", ",GameServer.content.arenas.keySet())))).then(literal("stop").executes(c->{Modes.stopAll();return reply(c.getSource(),"Partidas encerradas.");})).then(literal("start").then(argument("arena",StringArgumentType.word()).suggests((c,b)->SharedSuggestionProvider.suggest(GameServer.content.arenas.keySet(),b)).then(argument("players",EntityArgument.players()).executes(c->{List<ServerPlayer> players=new ArrayList<>(EntityArgument.getPlayers(c,"players"));players.sort(Comparator.comparing(p->p.getGameProfile().getName()));return reply(c.getSource(),Modes.startMatch(players,StringArgumentType.getString(c,"arena"))?"Partida iniciada; times alternam por ordem alfabética.":"Selecione 2 ou 4 lutadores na mesma dimensão.");})))));
    }
    private Commands(){}
}
