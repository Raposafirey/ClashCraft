package com.seunome.clashcraft.server;
import com.google.gson.*;
import com.mojang.serialization.JsonOps;
import com.seunome.clashcraft.ClashCraft;
import com.seunome.clashcraft.config.Settings;
import java.nio.file.*;
import java.io.IOException;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.LevelResource;
import net.neoforged.neoforge.common.CommonHooks;
import static com.seunome.clashcraft.core.Definitions.*;
/** Escreve o diário antes da remoção. Não gera drops e não remove inventários. */
public final class BlockJournal {
    private record Entry(String dimension,long pos,JsonElement state,long restoreAt){}
    private static final List<Entry> entries=new ArrayList<>();private static Path path;private static boolean available;
    public static void load(MinecraftServer server){entries.clear();path=server.getWorldPath(LevelResource.ROOT).resolve("clashcraft-block-journal.json");available=true;if(!Files.exists(path))return;try{for(JsonElement e:JsonParser.parseString(Files.readString(path)).getAsJsonArray()){JsonObject j=e.getAsJsonObject();entries.add(new Entry(j.get("dimension").getAsString(),j.get("pos").getAsLong(),j.get("state"),j.get("restoreAt").getAsLong()));}}catch(Exception e){available=false;ClashCraft.LOG.error("Diário inválido: novas crateras desativadas",e);}}
    private static boolean save(){if(!available||path==null)return false;try{Path temp=path.resolveSibling(path.getFileName()+".tmp");Files.writeString(temp,JSON.toJson(entries));try{Files.move(temp,path,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException ex){Files.move(temp,path,StandardCopyOption.REPLACE_EXISTING);}return true;}catch(IOException ex){available=false;ClashCraft.LOG.error("Falha no diário; novas crateras desativadas",ex);return false;}}
    public static void impact(ServerPlayer player,int radius){ServerLevel level=player.serverLevel();if(!available||!Settings.DESTRUCTION.get()||!level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)||entries.size()>=2048)return;List<Entry> added=new ArrayList<>();BlockPos center=player.blockPosition().below();int limit=Settings.MAX_BLOCKS.get();outer:for(int y=-1;y<=0;y++)for(int x=-radius;x<=radius;x++)for(int z=-radius;z<=radius;z++){if(added.size()>=limit||entries.size()+added.size()>=2048)break outer;if(x*x+z*z>radius*radius)continue;BlockPos pos=center.offset(x,y,z);if(!level.getChunkSource().hasChunk(pos.getX()>>4,pos.getZ()>>4))continue;BlockState state=level.getBlockState(pos);if(state.isAir()||state.hasBlockEntity()||!state.getFluidState().isEmpty()||state.getDestroySpeed(level,pos)<0||!state.isSolidRender(level,pos)||!CommonHooks.canEntityDestroy(level,pos,player))continue;added.add(new Entry(level.dimension().location().toString(),pos.asLong(),BlockState.CODEC.encodeStart(JsonOps.INSTANCE,state).getOrThrow(),level.getGameTime()+600));}entries.addAll(added);if(!save()){entries.removeAll(added);return;}for(Entry e:added)level.setBlock(BlockPos.of(e.pos),Blocks.AIR.defaultBlockState(),3);}
    public static void tick(MinecraftServer server){if(!available)return;boolean changed=false;int restored=0;Iterator<Entry> it=entries.iterator();while(it.hasNext()&&restored<4){Entry e=it.next();ServerLevel level=server.getLevel(ResourceKey.create(Registries.DIMENSION,ResourceLocation.parse(e.dimension)));BlockPos pos=BlockPos.of(e.pos);if(level==null||!level.getChunkSource().hasChunk(pos.getX()>>4,pos.getZ()>>4)||level.getGameTime()<e.restoreAt)continue;try{if(level.getBlockState(pos).isAir())level.setBlock(pos,BlockState.CODEC.parse(JsonOps.INSTANCE,e.state).getOrThrow(),3);it.remove();changed=true;restored++;}catch(RuntimeException ex){available=false;ClashCraft.LOG.error("Falha na restauração; diário preservado",ex);break;}}if(changed)save();}
    public static void clear(){entries.clear();path=null;available=false;}
    private BlockJournal(){}
}
