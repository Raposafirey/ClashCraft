package com.seunome.clashcraft.config;
import net.neoforged.neoforge.common.ModConfigSpec;
public final class Settings {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.BooleanValue DEBUG,FRIENDLY_FIRE,FLIGHT,DESTRUCTION;
    public static final ModConfigSpec.DoubleValue DAMAGE,REGEN;
    public static final ModConfigSpec.IntValue BUFFER,COMBO_LIMIT,MAX_BLOCKS;
    static {ModConfigSpec.Builder b=new ModConfigSpec.Builder();DEBUG=b.define("debug",false);FRIENDLY_FIRE=b.define("friendlyFire",false);FLIGHT=b.define("allowFlight",true);DESTRUCTION=b.define("environmentDestruction",false);DAMAGE=b.defineInRange("damageMultiplier",1.,.1,10.);REGEN=b.defineInRange("energyRegenMultiplier",1.,0.,10.);BUFFER=b.defineInRange("inputBufferTicks",7,1,20);COMBO_LIMIT=b.defineInRange("comboLimit",12,1,30);MAX_BLOCKS=b.defineInRange("maxBlocksPerImpact",24,0,128);SPEC=b.build();}
    private Settings(){}
}
