package com.seunome.clashcraft.client;
import com.google.gson.JsonObject;
import com.seunome.clashcraft.ClashCraft;
import com.seunome.clashcraft.core.FighterData;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.*;
import software.bernie.geckolib.animatable.GeoReplacedEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoReplacedEntityRenderer;
import software.bernie.geckolib.util.GeckoLibUtil;
import static com.seunome.clashcraft.core.Definitions.*;
@EventBusSubscriber(modid="clashcraft",value=Dist.CLIENT)
public final class AvatarRenderer {
    private static EntityRendererProvider.Context context;
    private static final Map<UUID,GeoReplacedEntityRenderer<Player,Avatar>> renderers=new HashMap<>();
    private static final Set<String> errors=new HashSet<>();
    @SubscribeEvent public static void layers(EntityRenderersEvent.AddLayers e){context=e.getContext();clear();}
    public static void clear(){renderers.clear();errors.clear();}
    public static void retain(Set<UUID> ids){renderers.keySet().retainAll(ids);}
    @SubscribeEvent public static void render(RenderPlayerEvent.Pre e){Player player=e.getEntity();FighterData d=ClientMod.states.get(player.getUUID());if(context==null||d==null||!d.enabled||!ClientMod.definitions.containsKey(d.fighter))return;try{var renderer=renderers.computeIfAbsent(player.getUUID(),id->new GeoReplacedEntityRenderer<>(context,new Model(),new Avatar(id)));Avatar avatar=renderer.getAnimatable();JsonObject model=avatar.model();ResourceLocation geo=ResourceLocation.parse(text(model,"geo","clashcraft:geo/aurion.geo.json"));if(Minecraft.getInstance().getResourceManager().getResource(geo).isEmpty())return;renderer.withScale((float)number(model,"scale",1,.1,4));e.getPoseStack().pushPose();try{renderer.render(player,player.getYRot(),e.getPartialTick(),e.getPoseStack(),e.getMultiBufferSource(),e.getPackedLight());}finally{e.getPoseStack().popPose();}e.setCanceled(true);}catch(RuntimeException ex){if(errors.add(d.fighter))ClashCraft.LOG.warn("Modelo {} indisponível; fallback vanilla",d.fighter,ex);}}
    public static final class Avatar implements GeoReplacedEntity {
        private final UUID id;private final AnimatableInstanceCache cache=GeckoLibUtil.createInstanceCache(this);Avatar(UUID id){this.id=id;}
        public FighterData data(){return ClientMod.states.get(id);}
        public JsonObject model(){FighterData d=data();Fighter f=d==null?null:ClientMod.definitions.get(d.fighter);if(f==null)return new JsonObject();Transformation t=ClientMod.transformations.get(d.transformation);return t==null?object(f.raw(),"model"):object(t.raw(),"model_override");}
        public EntityType<?> getReplacingEntityType(){return EntityType.PLAYER;}
        public AnimatableInstanceCache getAnimatableInstanceCache(){return cache;}
        public void registerControllers(AnimatableManager.ControllerRegistrar controllers){controllers.add(new AnimationController<>(this,"combat",2,state->{FighterData d=data();if(d==null)return PlayState.STOP;String name=switch(d.state){case "ATTACK"->d.animation;case "CASTING_ULTIMATE"->"ultimate";case "TRANSFORMING"->"transform";case "HITSTUN","BLOCKSTUN","LAUNCHED","KNOCKDOWN","GRABBED"->"hit";case "WALK","RUN"->"walk";case "JUMP","FALL","FLY"->"fly";case "GUARD"->"guard";case "DODGE"->"dodge";case "KO"->"ko";default->"idle";};state.getController().setAnimationSpeed(d.hitstop>0?0:1);state.setAnimation(RawAnimation.begin().thenLoop(name));return PlayState.CONTINUE;}));}
    }
    @SuppressWarnings("deprecation") // Estes métodos abstratos ainda são obrigatórios na GeckoLib 4.9.3.
    private static final class Model extends GeoModel<Avatar> {
        public ResourceLocation getModelResource(Avatar a){return ResourceLocation.parse(text(a.model(),"geo","clashcraft:geo/aurion.geo.json"));}
        public ResourceLocation getTextureResource(Avatar a){return ResourceLocation.parse(text(a.model(),"texture","clashcraft:textures/fighter/aurion.png"));}
        public ResourceLocation getAnimationResource(Avatar a){return ResourceLocation.parse(text(a.model(),"animations","clashcraft:animations/aurion.animation.json"));}
    }
    private AvatarRenderer(){}
}
