package com.seunome.clashcraft.core;

import com.google.gson.*;
import java.util.*;
import static com.seunome.clashcraft.core.Definitions.*;

/** Publica apenas um conjunto coerente; dados inválidos não derrubam o reload. */
public final class Content {
    public final Map<String,Fighter> fighters;
    public final Map<String,Move> moves;
    public final Map<String,Transformation> transformations;
    public final Map<String,JsonObject> interactions,arenas,missions;
    public final List<String> errors;
    public Content(Map<String,JsonObject> files){
        Map<String,Fighter> fs=new LinkedHashMap<>();Map<String,Move> ms=new LinkedHashMap<>();Map<String,Transformation> ts=new LinkedHashMap<>();Map<String,JsonObject> ins=new LinkedHashMap<>(),ars=new LinkedHashMap<>(),mis=new LinkedHashMap<>();List<String> errs=new ArrayList<>();
        files.forEach((path,j)->{try{header(j);String id=text(j,"id","");String[] p=path.split("/",2);if(p.length!=2||!id.equals(p[1]))throw error("id","não coincide com caminho");switch(p[0]){
            case "fighters"->fs.put(id,fighter(j));case "moves"->ms.put(id,move(j));case "transformations"->ts.put(id,transformation(j));
            case "interactions"->{strings(j,"participants");if(!Set.of("rivalry","team_ultimate","beam_clash","assist","arena_event","easter_egg").contains(text(j,"type","")))throw error("type","interação desconhecida");ins.put(id,j.deepCopy());}
            case "arenas"->{integer(j,"rounds",3,1,9);integer(j,"round_time_seconds",99,10,3600);ars.put(id,j.deepCopy());}
            case "missions"->{integer(j,"target_count",1,1,8);bool(j,"boss",false);mis.put(id,j.deepCopy());}
            default->throw error("pasta","desconhecida");}
        }catch(RuntimeException e){errs.add(path+" | "+e.getMessage());}});
        boolean changed;do{changed=false;Iterator<Move> it=ms.values().iterator();while(it.hasNext()){Move m=it.next();for(String ref:m.cancels())if(!ms.containsKey(ref)){errs.add(m.id()+" | cancel.into | referência ausente "+ref);it.remove();changed=true;break;}}}while(changed);
        ts.values().removeIf(t->{for(String ref:t.overrides().values())if(!ms.containsKey(ref)){errs.add(t.id()+" | move_overrides | referência ausente "+ref);return true;}return false;});
        fs.values().removeIf(f->{List<String> refs=new ArrayList<>(f.chain());refs.addAll(f.moves().values());for(String ref:refs)if(!ms.containsKey(ref)){errs.add(f.id()+" | moves | referência ausente "+ref);return true;}if(!ts.containsKey(f.transformation())){errs.add(f.id()+" | transformation | referência ausente");return true;}return false;});
        ins.values().removeIf(j->{for(String ref:strings(j,"participants"))if(!fs.containsKey(ref)){errs.add(text(j,"id","")+" | participants | referência ausente");return true;}return false;});
        fighters=Collections.unmodifiableMap(fs);moves=Collections.unmodifiableMap(ms);transformations=Collections.unmodifiableMap(ts);interactions=Collections.unmodifiableMap(ins);arenas=Collections.unmodifiableMap(ars);missions=Collections.unmodifiableMap(mis);errors=List.copyOf(errs);
    }
    public static Content empty(){return new Content(Map.of());}
}
