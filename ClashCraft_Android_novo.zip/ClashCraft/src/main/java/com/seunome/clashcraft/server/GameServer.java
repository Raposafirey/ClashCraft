package com.seunome.clashcraft.server;

import com.google.gson.*;
import com.seunome.clashcraft.ClashCraft;
import com.seunome.clashcraft.config.Settings;
import com.seunome.clashcraft.core.*;
import com.seunome.clashcraft.network.Packets;
import java.util.*;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.common.NeoForgeMod;
import net.neoforged.neoforge.event.AddReloadListenerEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.player.*;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.server.*;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import static com.seunome.clashcraft.core.Definitions.*;

/** Toda decisão de combate ocorre na thread do servidor. */
public final class GameServer {
    public static Content content=Content.empty();
    public static List<String> loadErrors=List.of();
    public static int contentRevision=0;
    private static final Map<UUID,FighterData> fighters=new HashMap<>();
    private static final Map<UUID,Integer> revisions=new HashMap<>();
    private static final List<Shot> shots=new ArrayList<>();
    private static int smokeTicks=0;
    private static final String SAVE="clashcraft_state";
    private static final ResourceLocation FLIGHT=ResourceLocation.fromNamespaceAndPath("clashcraft","flight"),SPEED=ResourceLocation.fromNamespaceAndPath("clashcraft","speed");
    public static FighterData data(ServerPlayer p){return fighters.computeIfAbsent(p.getUUID(),id->{FighterData d;try{String json=p.getPersistentData().getString(SAVE);d=json.isEmpty()?new FighterData():JSON.fromJson(json,FighterData.class);if(d==null)d=new FighterData();d.restoreTransient();}catch(RuntimeException ex){ClashCraft.LOG.warn("Estado inválido: {}",id);d=new FighterData();}Fighter f=content.fighters.get(d.fighter);if(f!=null)d.normalize(f);return d;});}
    public static void save(ServerPlayer p){p.getPersistentData().putString(SAVE,JSON.toJson(data(p)));}
    @SubscribeEvent public static void reload(AddReloadListenerEvent e){e.addListener(new ContentLoader());}
    @SubscribeEvent public static void commands(RegisterCommandsEvent e){Commands.register(e.getDispatcher());}
    @SubscribeEvent public static void started(ServerStartedEvent e){BlockJournal.load(e.getServer());smokeTicks=0;}
    @SubscribeEvent public static void stop(ServerStoppedEvent e){fighters.clear();revisions.clear();shots.clear();Modes.clear();BeamClashes.clear();BlockJournal.clear();content=Content.empty();}
    @SubscribeEvent public static void login(PlayerEvent.PlayerLoggedInEvent e){if(e.getEntity() instanceof ServerPlayer p){data(p);syncDefinitions(p);p.sendSystemMessage(Component.literal("ClashCraft: /fighter list | K: seleção | R: modo luta"));}}
    @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent e){if(e.getEntity() instanceof ServerPlayer p){releaseMovement(p);save(p);Modes.leave(p);shots.removeIf(s->s.owner.equals(p.getUUID()));fighters.remove(p.getUUID());revisions.remove(p.getUUID());}}
    @SubscribeEvent public static void clone(PlayerEvent.Clone e){if(e.getEntity() instanceof ServerPlayer p){FighterData d=fighters.get(p.getUUID());if(d==null){p.getPersistentData().putString(SAVE,e.getOriginal().getPersistentData().getString(SAVE));d=data(p);}d.resetAction();d.flying=false;d.target="";d.transformation="";d.transformTicks=0;Fighter f=content.fighters.get(d.fighter);if(f!=null)d.health=f.maxHealth();save(p);revisions.remove(p.getUUID());}}
    @SubscribeEvent public static void changed(PlayerEvent.PlayerChangedDimensionEvent e){if(e.getEntity() instanceof ServerPlayer p){data(p).resetAction();data(p).target="";releaseMovement(p);revisions.remove(p.getUUID());Modes.leave(p);}}
    @SubscribeEvent public static void attack(AttackEntityEvent e){if(e.getEntity() instanceof ServerPlayer p&&data(p).enabled)e.setCanceled(true);}
    @SubscribeEvent public static void vanillaDamage(LivingIncomingDamageEvent e){if(e.getEntity() instanceof ServerPlayer p){FighterData d=data(p);if(d.enabled&&content.fighters.containsKey(d.fighter)&&!e.getSource().getMsgId().equals("genericKill")){e.setCanceled(true);if(d.state.equals("DODGE")||d.health<=0||d.state.equals("CASTING_ULTIMATE"))return;d.health=Math.max(0,d.health-e.getAmount());if(d.health==0)knockout(p,d);}}}
    public static void syncDefinitions(ServerPlayer p){Packets.send(p,new Packets.Snapshot("clear","","{}"));content.fighters.values().forEach(f->Packets.send(p,new Packets.Snapshot("fighter",f.id(),JSON.toJson(f.raw()))));content.transformations.values().forEach(t->Packets.send(p,new Packets.Snapshot("transform",t.id(),JSON.toJson(t.raw()))));for(ServerPlayer other:p.getServer().getPlayerList().getPlayers())Packets.send(p,new Packets.Snapshot("state",other.getUUID().toString(),JSON.toJson(data(other))));revisions.put(p.getUUID(),contentRevision);}
    public static boolean select(ServerPlayer p,String id){Fighter f=content.fighters.get(id);FighterData d=data(p);if(f==null||Modes.inMatch(p))return false;if(id.equals("clashcraft:noctis")&&!d.unlocked.contains(id)&&!p.hasPermissions(2)){p.sendSystemMessage(Component.literal("Conclua a missão Eclipse para desbloquear Noctis."));return false;}releaseMovement(p);d.select(f);save(p);return true;}
    public static void input(ServerPlayer p,Packets.Intent packet){
        if(!p.isAlive()||p.isSpectator())return;FighterData d=data(p);long now=p.serverLevel().getGameTime();if(!d.acceptPacket(now,packet.sequence())||packet.action()<0||packet.action()>=Input.values().length){if(Settings.DEBUG.get())ClashCraft.LOG.debug("Input recusado: {}",p.getUUID());return;}Input in=Input.values()[packet.action()];
        if(in==Input.SELECT){if(packet.pressed())select(p,packet.value());return;}if(!content.fighters.containsKey(d.fighter))return;
        if(in==Input.TOGGLE&&packet.pressed()){if(Modes.inMatch(p))return;d.enabled=!d.enabled;d.resetAction();releaseMovement(p);return;}if(!d.enabled)return;
        if(in==Input.GUARD&&!packet.pressed()){d.guarding=false;if(d.state.equals("GUARD")){d.state="IDLE";d.tick=0;}return;}if(!packet.pressed()||BeamClashes.input(p,in,now))return;d.enqueue(in,now,Settings.BUFFER.get());
    }
    @SubscribeEvent public static void tick(ServerTickEvent.Post e){
        MinecraftServer server=e.getServer();BeamClashes.tick(server);
        for(ServerPlayer p:server.getPlayerList().getPlayers()){
            if(revisions.getOrDefault(p.getUUID(),-1)!=contentRevision)syncDefinitions(p);FighterData d=data(p);Fighter f=content.fighters.get(d.fighter);long now=p.serverLevel().getGameTime();
            if(f==null){if(d.enabled){d.enabled=false;releaseMovement(p);}continue;}if(p.isSpectator()&&d.enabled){d.enabled=false;releaseMovement(p);}
            if(d.enabled){
                d.prune(now);Transformation t=content.transformations.get(d.transformation);boolean frozen=d.hitstop>0;int oldStun=d.stun;
                if(d.canAct())processInput(p,d,f,now);if(!frozen&&d.stun==0&&!d.move.isEmpty())attackTick(p,d,f);
                if(oldStun>0||frozen||d.statuses.containsKey("clashcraft:freeze"))p.setDeltaMovement(0,p.getDeltaMovement().y,0);
                int clashTick=d.tick;d.stepTimers(f,t,Settings.REGEN.get());if(BeamClashes.contains(p))d.tick=clashTick;
                if(now%20==0)for(String status:List.of("clashcraft:burn","clashcraft:bleed"))if(d.statuses.containsKey(status))d.health=Math.max(0,d.health-2*d.stacks.getOrDefault(status,1));
                if(d.health<=0&&!d.state.equals("KO"))knockout(p,d);if(d.statuses.containsKey("clashcraft:slow"))p.setDeltaMovement(p.getDeltaMovement().multiply(.65,1,.65));
                if(p.onGround())d.airDashes=0;updateMovement(p,d,f);updateTarget(p,d);
                if(!d.transformation.isEmpty()&&now%4==0)p.serverLevel().sendParticles(ParticleTypes.END_ROD,p.getX(),p.getY()+1,p.getZ(),3,.4,.7,.4,.02);
                if(!d.move.isEmpty()&&!content.moves.containsKey(d.move))d.resetAction();
                if((d.state.equals("DODGE")&&d.tick>=6)||(d.state.equals("TRANSFORMING")&&d.tick>=40)){d.state="IDLE";d.tick=0;}
                if(d.move.isEmpty()&&d.stun==0&&!d.guarding&&!Set.of("KO","DODGE","TRANSFORMING").contains(d.state))d.state=d.flying?"FLY":!p.onGround()?(p.getDeltaMovement().y>0?"JUMP":"FALL"):p.getDeltaMovement().horizontalDistanceSqr()>.005?(p.isSprinting()?"RUN":"WALK"):"IDLE";
                if(now-d.lastHitTick>30){d.combo=0;d.comboDamage=0;d.juggle=0;}
            }
            if(now%100==0)save(p);if(now-d.lastSync>=2){String json=JSON.toJson(d);if(!json.equals(d.snapshot)){for(ServerPlayer recipient:server.getPlayerList().getPlayers())if(recipient==p||(recipient.level()==p.level()&&recipient.distanceToSqr(p)<16384))Packets.send(recipient,new Packets.Snapshot("state",p.getUUID().toString(),json));d.snapshot=json;}d.lastSync=now;}
        }
        tickShots(server);Modes.tick(server);BlockJournal.tick(server);
        // Encerramento automático apenas quando solicitado explicitamente pelo teste de CI.
        if(Boolean.getBoolean("clashcraft.smokeTest")&&++smokeTicks==100){ClashCraft.LOG.info("CLASHCRAFT_SMOKE: fighters={} moves={} errors={}",content.fighters.size(),content.moves.size(),loadErrors.size());server.halt(false);}
    }
    private static void processInput(ServerPlayer p,FighterData d,Fighter f,long now){
        if(d.buffer.isEmpty()||Set.of("DODGE","TRANSFORMING","CASTING_ULTIMATE","CHARGING").contains(d.state))return;Input in=d.buffer.peekFirst().input();
        if(in==Input.GUARD){if(!d.move.isEmpty())return;d.buffer.removeFirst();d.guarding=true;d.guardStarted=now;d.state="GUARD";d.tick=0;return;}
        if(in==Input.LOCK_ON){d.buffer.removeFirst();List<LivingEntity> targets=p.serverLevel().getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(24),v->v!=p&&v.isAlive()&&p.hasLineOfSight(v));targets.sort(Comparator.comparingDouble(p::distanceToSqr));if(targets.isEmpty()){d.target="";return;}int index=-1;for(int i=0;i<targets.size();i++)if(targets.get(i).getUUID().toString().equals(d.target))index=i;d.target=targets.get((index+1)%targets.size()).getUUID().toString();return;}
        if(in==Input.FLY){d.buffer.removeFirst();if(f.fly()&&Settings.FLIGHT.get()&&d.move.isEmpty()){d.flying=!d.flying;if(!d.flying)releaseMovement(p);}else if(f.doubleJump()&&!p.onGround()&&d.airDashes==0&&d.energy>=5){d.airDashes++;d.energy-=5;p.setDeltaMovement(p.getDeltaMovement().x,.65,p.getDeltaMovement().z);p.hurtMarked=true;}return;}
        if(in==Input.DODGE){if(!d.move.isEmpty())return;d.buffer.removeFirst();if(d.energy<10||d.cooldowns.containsKey("dodge")||(!p.onGround()&&d.airDashes>0))return;d.energy-=10;d.cooldowns.put("dodge",20);d.state="DODGE";d.tick=0;d.guarding=false;if(!p.onGround())d.airDashes++;Vec3 v=p.getLookAngle().multiply(1,0,1).normalize().scale(1.2*f.speed());p.setDeltaMovement(v.x,.1,v.z);p.hurtMarked=true;return;}
        if(in==Input.TRANSFORM){if(!d.move.isEmpty())return;d.buffer.removeFirst();Transformation t=content.transformations.get(f.transformation());if(t==null||!d.transformation.isEmpty()||d.transformCooldown>0||d.ultimate<t.requirement())return;d.transformation=t.id();d.transformTicks=t.duration();d.state="TRANSFORMING";d.tick=0;fx(p,"transform");return;}
        if(in==Input.ASSIST){if(!d.move.isEmpty())return;d.buffer.removeFirst();if(d.energy>=25&&!d.cooldowns.containsKey("assist")){d.energy-=25;d.cooldowns.put("assist",200);Modes.assist(p);}return;}
        String key=in.name().toLowerCase(Locale.ROOT),id=in==Input.LIGHT?(!p.onGround()?f.moves().get("air_light"):f.chain().get(d.move.isEmpty()?0:Math.min(d.chainIndex+1,f.chain().size()-1))):f.moves().get(key);Transformation t=content.transformations.get(d.transformation);if(t!=null)id=t.overrides().getOrDefault(key,id);Move m=content.moves.get(id);if(m==null){d.buffer.removeFirst();return;}
        if(!d.move.isEmpty()){Move prev=content.moves.get(d.move);if(prev==null||d.tick<prev.cancelStart()||d.tick>prev.cancelEnd()||!prev.cancels().contains(m.id()))return;}
        boolean chained=!d.move.isEmpty();if(d.start(m,!p.onGround())){d.buffer.removeFirst();d.chainIndex=chained?d.chainIndex+1:0;if(m.type()==MoveType.ultimate){fx(p,"ultimate");Modes.teamUltimate(p);}}
    }
    private static void attackTick(ServerPlayer p,FighterData d,Fighter f){
        if(BeamClashes.contains(p))return;Move m=content.moves.get(d.move);if(m==null){d.resetAction();return;}if(d.tick>=m.frames().total()){d.move="";d.state="IDLE";d.tick=0;d.chainIndex=0;return;}if(!m.frames().activeAt(d.tick))return;
        if(m.type()==MoveType.projectile){if(!d.emitted){if(shots.size()<128)shots.add(new Shot(p,m));d.emitted=true;}return;}
        if(m.type()==MoveType.buff){if(!d.emitted){d.health=Math.min(f.maxHealth(),d.health+m.damage());d.statuses.put("clashcraft:power",100);d.emitted=true;fx(p,"heal");}return;}
        if(m.type()==MoveType.summon_assist){if(!d.emitted){Modes.assist(p);d.emitted=true;}return;}
        if(m.type()==MoveType.dash_attack){p.setDeltaMovement(p.getLookAngle().scale(.65));p.hurtMarked=true;}
        if(m.type()==MoveType.beam){if(d.tick%3!=0)return;Set<UUID> hitThisTick=new HashSet<>();Vec3 from=p.getEyePosition(),dir=p.getLookAngle();for(int i=1;i<=20;i++){Vec3 v=from.add(dir.scale(i));if(!clear(p,from,v))break;p.serverLevel().sendParticles(ParticleTypes.ELECTRIC_SPARK,v.x,v.y,v.z,2,.12,.12,.12,0);for(LivingEntity target:p.serverLevel().getEntitiesOfClass(LivingEntity.class,new AABB(v,v).inflate(.6)))if(target!=p&&hitThisTick.add(target.getUUID()))hit(p,d,f,target,m,false);}return;}
        if(m.type()==MoveType.area||m.type()==MoveType.ultimate){if(!d.emitted){d.emitted=true;if(m.type()==MoveType.ultimate)BlockJournal.impact(p,3);}for(LivingEntity target:p.serverLevel().getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(m.type()==MoveType.ultimate?7:4)))if(target!=p)hit(p,d,f,target,m,true);return;}
        for(Hitbox box:m.boxes())if(d.tick>=box.from()&&d.tick<=box.to()){
            double yaw=Math.toRadians(p.getYRot());Vec3 forward=new Vec3(-Math.sin(yaw),0,Math.cos(yaw)),right=new Vec3(Math.cos(yaw),0,Math.sin(yaw));Vec3 center=p.position().add(forward.scale(box.offset().z())).add(right.scale(box.offset().x())).add(0,box.offset().y(),0);double hx=box.size().x()/2,hz=box.size().z()/2,hy=box.size().y()/2;
            for(LivingEntity target:p.serverLevel().getEntitiesOfClass(LivingEntity.class,new AABB(center,center).inflate(hx+hz,hy,hx+hz))){Vec3 delta=target.getBoundingBox().getCenter().subtract(center);double r=target.getBbWidth()/2;if(Math.abs(delta.dot(right))<=hx+r&&Math.abs(delta.dot(forward))<=hz+r)hit(p,d,f,target,m,box.once());}
        }
    }
    public static boolean clear(ServerPlayer p,Vec3 from,Vec3 to){return p.level().clip(new ClipContext(from,to,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,p)).getType()==HitResult.Type.MISS;}
    private static boolean enemy(ServerPlayer p,LivingEntity target){return !(data(p).training&&target instanceof ServerPlayer)&&target!=p&&target.isAlive()&&!target.isSpectator()&&(Settings.FRIENDLY_FIRE.get()||!p.isAlliedTo(target))&&Modes.canHit(p,target);}
    private static void hit(ServerPlayer p,FighterData a,Fighter f,LivingEntity victim,Move m,boolean once){
        String uid=victim.getUUID().toString();if(!enemy(p,victim)||!p.hasLineOfSight(victim)||(once&&a.hitTargets.contains(uid)))return;FighterData b=victim instanceof ServerPlayer sp?data(sp):null;
        if(b!=null&&(!b.enabled||b.health<=0||b.state.equals("DODGE")||b.state.equals("CASTING_ULTIMATE")))return;
        long now=p.serverLevel().getGameTime();if(!uid.equals(a.comboTarget)||(b!=null&&b.stun==0&&now>a.lastHitTick)){a.combo=0;a.comboDamage=0;a.juggle=0;}a.comboTarget=uid;
        if(a.combo>=Settings.COMBO_LIMIT.get()||(!victim.onGround()&&a.juggle>=6))return;if(once)a.hitTargets.add(uid);
        Transformation at=content.transformations.get(a.transformation),bt=b==null?null:content.transformations.get(b.transformation);Fighter vf=b==null?null:content.fighters.get(b.fighter);
        double attack=f.attack()*(at==null?1:at.attack())*(a.statuses.containsKey("clashcraft:weakness")?.7:1)*(a.statuses.containsKey("clashcraft:power")?1.15:1);JsonObject passive=object(f.raw(),"passive"),params=object(passive,"params");
        if(text(passive,"id","").equals("clashcraft:passive_rising_aura"))attack*=1+Math.min(number(params,"max_bonus",.2,0,2),a.combo*number(params,"damage_bonus_per_combo_hit",.02,0,1));
        double base=m.type()==MoveType.beam?m.damage()/Math.ceil(m.frames().active()/3.0):m.damage();double damage=FighterData.damage(base*Settings.DAMAGE.get(),attack,vf==null?1:vf.defense()*(bt==null?1:bt.defense()),a.combo);boolean blocked=false;
        if(b!=null&&b.guarding&&m.type()!=MoveType.grab&&victim.getLookAngle().dot(p.position().subtract(victim.position()).normalize())>0){blocked=true;if(now-b.guardStarted<=3){damage=0;a.stun=8;a.move="";a.state="HITSTUN";fx((ServerPlayer)victim,"perfect");}else{damage*=.15;b.guard=Math.max(0,b.guard-m.guardDamage());b.stun=b.guard==0?30:m.blockstun();b.state="BLOCKSTUN";if(b.guard==0){b.guarding=false;fx((ServerPlayer)victim,"break");}}a.ultimate+=m.blockGain();}
        if(b!=null){b.health=Math.max(0,b.health-damage);b.ultimate+=damage*.35;b.hitstop=m.hitstop();if(!blocked){boolean armor=vf!=null&&vf.archetype().equals("tank")&&!b.move.isEmpty()&&m.type()!=MoveType.grab;if(!armor){b.stun=m.hitstun();b.move="";b.state=m.launch()?"LAUNCHED":"HITSTUN";b.tick=0;b.guarding=false;}for(Status s:m.statuses()){b.statuses.merge(s.id(),s.ticks(),Math::max);b.stacks.merge(s.id(),s.stacks(),(x,y)->Math.min(3,x+y));}}if(b.health==0)knockout((ServerPlayer)victim,b);}
        else{if(victim.getTags().contains("clashcraft_guard")&&m.type()!=MoveType.grab){damage*=.15;blocked=true;}victim.invulnerableTime=0;victim.hurt(p.damageSources().playerAttack(p),(float)damage);if(victim.getTags().contains("clashcraft_dummy"))victim.setHealth(victim.getMaxHealth());}
        if(!blocked){a.energy+=m.energyGain();a.ultimate+=m.ultimateGain();a.combo++;a.maxCombo=Math.max(a.maxCombo,a.combo);a.comboDamage+=damage;if(!victim.onGround())a.juggle++;}a.lastHitTick=now;a.lastDamage=damage;a.totalDamage+=damage;a.hitstop=m.hitstop();
        if(!blocked){Vec3 dir=victim.position().subtract(p.position()).multiply(1,0,1).normalize();victim.setDeltaMovement(dir.x*m.horizontal(),m.vertical(),dir.z*m.horizontal());victim.hurtMarked=true;}
        p.serverLevel().sendParticles(blocked?ParticleTypes.CRIT:ParticleTypes.DAMAGE_INDICATOR,victim.getX(),victim.getY()+1,victim.getZ(),6,.3,.3,.3,.1);p.serverLevel().playSound(null,victim.blockPosition(),blocked?SoundEvents.SHIELD_BLOCK:SoundEvents.PLAYER_ATTACK_STRONG,SoundSource.PLAYERS,.7f,1);fx(p,blocked?"block":"hit");if(!victim.isAlive())Modes.defeated(p,victim);
    }
    public static void clashHit(ServerPlayer winner,ServerPlayer loser){FighterData d=data(winner);Fighter f=content.fighters.get(d.fighter);Move m=content.moves.get(d.move);if(f!=null&&m!=null)hit(winner,d,f,loser,m,false);}
    public static void knockout(ServerPlayer p,FighterData d){d.health=0;d.state="KO";d.move="";d.guarding=false;d.target="";d.transformation="";d.transformTicks=0;d.buffer.clear();releaseMovement(p);fx(p,"ko");}
    private static void updateTarget(ServerPlayer p,FighterData d){if(d.target.isEmpty())return;Entity e;try{e=p.serverLevel().getEntity(UUID.fromString(d.target));}catch(IllegalArgumentException ex){d.target="";return;}if(!(e instanceof LivingEntity target)||!target.isAlive()||p.distanceToSqr(target)>1024||!p.hasLineOfSight(target)){d.target="";return;}Vec3 delta=target.position().subtract(p.position());float yaw=(float)Math.toDegrees(Math.atan2(-delta.x,delta.z));p.setYRot(yaw);p.yHeadRot=yaw;}
    private static void updateMovement(ServerPlayer p,FighterData d,Fighter f){if(d.health<=0)return;var speed=p.getAttribute(Attributes.MOVEMENT_SPEED);Transformation t=content.transformations.get(d.transformation);double amount=f.speed()*(t==null?1:t.speed())-1;if(speed!=null&&(speed.getModifier(SPEED)==null||speed.getModifier(SPEED).amount()!=amount)){speed.removeModifier(SPEED);speed.addTransientModifier(new AttributeModifier(SPEED,amount,AttributeModifier.Operation.ADD_MULTIPLIED_BASE));}if(!d.flying||!Settings.FLIGHT.get()||!f.fly()||d.energy<.2){if(d.flying)releaseMovement(p);return;}var attr=p.getAttribute(NeoForgeMod.CREATIVE_FLIGHT);if(attr==null)return;if(attr.getModifier(FLIGHT)==null)attr.addTransientModifier(new AttributeModifier(FLIGHT,1,AttributeModifier.Operation.ADD_VALUE));d.energy-=.2;if(!p.getAbilities().flying){p.getAbilities().flying=true;p.onUpdateAbilities();}p.fallDistance=0;}
    public static void releaseMovement(ServerPlayer p){FighterData d=fighters.get(p.getUUID());if(d!=null)d.flying=false;var a=p.getAttribute(NeoForgeMod.CREATIVE_FLIGHT);if(a!=null)a.removeModifier(FLIGHT);var s=p.getAttribute(Attributes.MOVEMENT_SPEED);if(s!=null)s.removeModifier(SPEED);if(!p.mayFly()){p.getAbilities().flying=false;p.onUpdateAbilities();}}
    public static void fx(ServerPlayer p,String kind){Packets.send(p,new Packets.Snapshot("fx",kind,"{}"));}
    private static final class Shot {final UUID owner;final ServerLevel level;final Move move;Vec3 pos,velocity;int life;final Set<UUID> hit=new HashSet<>();Shot(ServerPlayer p,Move m){owner=p.getUUID();level=p.serverLevel();move=m;pos=p.getEyePosition();JsonObject j=object(m.raw(),"projectile");velocity=p.getLookAngle().scale(number(j,"speed",.8,.1,4));life=integer(j,"lifetime_ticks",60,1,200);}}
    private static void tickShots(MinecraftServer server){Iterator<Shot> it=shots.iterator();while(it.hasNext()){Shot s=it.next();ServerPlayer p=server.getPlayerList().getPlayer(s.owner);if(p==null||p.level()!=s.level||--s.life<=0||!data(p).enabled){it.remove();continue;}Vec3 next=s.pos.add(s.velocity);if(!clear(p,s.pos,next)){it.remove();continue;}boolean struck=false;for(LivingEntity target:s.level.getEntitiesOfClass(LivingEntity.class,new AABB(s.pos,next).inflate(.6))){if(!enemy(p,target)||s.hit.contains(target.getUUID()))continue;if(target.getBoundingBox().inflate(.35).clip(s.pos,next).isEmpty()&&!target.getBoundingBox().inflate(.35).contains(s.pos))continue;Fighter f=content.fighters.get(data(p).fighter);if(f!=null){hit(p,data(p),f,target,s.move,false);struck=true;}break;}if(struck){it.remove();continue;}s.pos=next;s.level.sendParticles(ParticleTypes.END_ROD,next.x,next.y,next.z,4,.1,.1,.1,.01);}for(int i=0;i<shots.size();i++)for(int j=i+1;j<shots.size();j++){Shot a=shots.get(i),b=shots.get(j);if(a.level==b.level&&!a.owner.equals(b.owner)&&a.pos.distanceToSqr(b.pos)<1){a.life=0;b.life=0;a.level.sendParticles(ParticleTypes.EXPLOSION,a.pos.x,a.pos.y,a.pos.z,1,0,0,0,0);}}}
    private GameServer(){}
}
