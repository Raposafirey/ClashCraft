package com.seunome.clashcraft.core;

import com.google.gson.*;
import java.util.*;

/** Validação explícita dos contratos JSON, sem dependência do cliente. */
public final class Definitions {
    public static final Gson JSON=new GsonBuilder().setPrettyPrinting().create();
    public enum Input { LIGHT,HEAVY,SPECIAL_1,SPECIAL_2,ULTIMATE,GUARD,DODGE,TRANSFORM,LOCK_ON,ASSIST,TOGGLE,FLY,SELECT }
    public enum MoveType { melee,projectile,beam,area,dash_attack,grab,buff,summon_assist,transform,ultimate }
    public record Frames(int startup,int active,int recovery) {
        public Frames {if(startup<0||active<1||recovery<0||(long)startup+active+recovery>1200)throw error("frames","duração inválida");}
        public int total(){return startup+active+recovery;}
        public boolean activeAt(int t){return t>=startup&&t<startup+active;}
    }
    public record Vec(double x,double y,double z) {}
    public record Hitbox(int from,int to,Vec offset,Vec size,boolean once) {}
    public record Status(String id,int ticks,int stacks) {}
    public record Move(String id,MoveType type,Frames frames,List<Hitbox> boxes,double damage,int hitstun,int blockstun,double guardDamage,double horizontal,double vertical,boolean launch,int hitstop,double energy,double ultimate,int cooldown,double energyGain,double ultimateGain,double blockGain,List<String> cancels,int cancelStart,int cancelEnd,boolean airborne,List<Status> statuses,JsonObject raw) {
        public Move {boxes=List.copyOf(boxes);cancels=List.copyOf(cancels);statuses=List.copyOf(statuses);raw=raw.deepCopy();}
        @Override public JsonObject raw(){return raw.deepCopy();}
    }
    public record Fighter(String id,String name,String archetype,double maxHealth,double attack,double defense,double speed,double maxEnergy,double regen,boolean fly,boolean doubleJump,List<String> chain,Map<String,String> moves,String transformation,JsonObject raw) {
        public Fighter {chain=List.copyOf(chain);moves=Map.copyOf(moves);raw=raw.deepCopy();}
        @Override public JsonObject raw(){return raw.deepCopy();}
    }
    public record Transformation(String id,int duration,double requirement,double drain,double attack,double defense,double speed,double regen,Map<String,String> overrides,int cooldown,JsonObject raw) {
        public Transformation {overrides=Map.copyOf(overrides);raw=raw.deepCopy();}
        @Override public JsonObject raw(){return raw.deepCopy();}
    }
    public static IllegalArgumentException error(String k,String why){return new IllegalArgumentException(k+": "+why);}
    public static JsonObject object(JsonObject j,String k){if(!j.has(k)||j.get(k).isJsonNull())return new JsonObject();if(!j.get(k).isJsonObject())throw error(k,"objeto esperado");return j.getAsJsonObject(k);}
    public static String text(JsonObject j,String k,String d){if(!j.has(k))return d;if(!j.get(k).isJsonPrimitive()||!j.getAsJsonPrimitive(k).isString())throw error(k,"texto esperado");return j.get(k).getAsString();}
    public static double number(JsonObject j,String k,double d,double min,double max){if(!j.has(k))return d;if(!j.get(k).isJsonPrimitive()||!j.getAsJsonPrimitive(k).isNumber())throw error(k,"número esperado");double v=j.get(k).getAsDouble();if(!Double.isFinite(v)||v<min||v>max)throw error(k,"fora de "+min+".."+max);return v;}
    public static int integer(JsonObject j,String k,int d,int min,int max){double v=number(j,k,d,min,max);if(v!=Math.rint(v))throw error(k,"inteiro esperado");return (int)v;}
    public static boolean bool(JsonObject j,String k,boolean d){if(!j.has(k))return d;if(!j.get(k).isJsonPrimitive()||!j.getAsJsonPrimitive(k).isBoolean())throw error(k,"booleano esperado");return j.get(k).getAsBoolean();}
    public static String id(String s){if(s==null||s.length()>160||!s.matches("[a-z0-9_.-]+:[a-z0-9_./-]+"))throw error("id","identificador inválido");return s;}
    public static void header(JsonObject j){if(integer(j,"schema_version",1,1,100)!=1)throw error("schema_version","versão desconhecida");id(text(j,"id",""));if(JSON.toJson(j).length()>24000)throw error("arquivo","limite de 24000 caracteres excedido");}
    public static List<String> strings(JsonObject j,String k){List<String> out=new ArrayList<>();if(j.has(k)){if(!j.get(k).isJsonArray())throw error(k,"lista esperada");for(JsonElement e:j.getAsJsonArray(k)){if(!e.isJsonPrimitive()||!e.getAsJsonPrimitive().isString())throw error(k,"texto esperado");out.add(id(e.getAsString()));}}return out;}
    public static Map<String,String> refs(JsonObject j){Map<String,String> r=new LinkedHashMap<>();j.entrySet().forEach(e->r.put(e.getKey(),id(e.getValue().getAsString())));return r;}
    public static Vec vector(JsonObject j,String k,Vec def,boolean positive){if(!j.has(k))return def;JsonArray a=j.getAsJsonArray(k);if(a.size()!=3)throw error(k,"vetor de três números esperado");double[] v=new double[3];for(int i=0;i<3;i++){v[i]=a.get(i).getAsDouble();if(!Double.isFinite(v[i])||Math.abs(v[i])>64||(positive&&v[i]<=0))throw error(k,"dimensão inválida");}return new Vec(v[0],v[1],v[2]);}
    public static Fighter fighter(JsonObject j){header(j);JsonObject s=object(j,"stats"),m=object(j,"moves");List<String> chain=strings(m,"light_chain");if(chain.isEmpty()||chain.size()>16)throw error("moves.light_chain","tamanho inválido");Map<String,String> refs=new LinkedHashMap<>();for(String k:List.of("heavy","air_light","special_1","special_2","ultimate"))refs.put(k,id(text(m,k,"")));return new Fighter(text(j,"id",""),text(j,"display_name","Lutador"),text(j,"archetype","brawler"),number(s,"max_health",100,1,10000),number(s,"attack",1,.01,100),number(s,"defense",1,.1,100),number(s,"speed",1,.1,5),number(s,"max_energy",100,1,10000),number(s,"energy_regen_per_sec",4,0,100),bool(s,"can_fly",false),bool(s,"double_jump",false),chain,refs,id(text(j,"transformation","")),j);}
    public static Move move(JsonObject j){
        header(j);JsonObject f=object(j,"frames"),c=object(j,"cancel"),k=object(j,"knockback"),cost=object(j,"cost"),gain=object(j,"gain");
        Frames frames=new Frames(integer(f,"startup",4,0,1200),integer(f,"active",3,1,1200),integer(f,"recovery",6,0,1200));int start=integer(c,"window_start",0,0,1200),end=integer(c,"window_end",frames.total()-1,0,1200);if(end<start||end>=frames.total())throw error("cancel","janela inválida");
        List<Hitbox> boxes=new ArrayList<>();if(j.has("hitboxes"))for(JsonElement e:j.getAsJsonArray("hitboxes")){JsonObject b=e.getAsJsonObject();int from=integer(b,"from_tick",frames.startup(),0,1200),to=integer(b,"to_tick",frames.startup()+frames.active()-1,0,1200);if(to<from||!frames.activeAt(from)||!frames.activeAt(to))throw error("hitboxes","janela fora de active");if(!text(b,"shape","box").equals("box"))throw error("hitboxes.shape","apenas box nesta versão");boxes.add(new Hitbox(from,to,vector(b,"offset",new Vec(0,1,1.2),false),vector(b,"size",new Vec(1.5,1.5,2),true),bool(b,"hit_once",true)));}
        List<Status> statuses=new ArrayList<>();if(j.has("status"))for(JsonElement e:j.getAsJsonArray("status")){JsonObject b=e.getAsJsonObject();String sid=id(text(b,"id",""));if(!Set.of("clashcraft:stun","clashcraft:burn","clashcraft:freeze","clashcraft:bleed","clashcraft:silence","clashcraft:slow","clashcraft:weakness").contains(sid))throw error("status.id","status desconhecido");statuses.add(new Status(sid,integer(b,"duration_ticks",40,1,12000),integer(b,"stacks",1,1,3)));}
        MoveType type;try{type=MoveType.valueOf(text(j,"type","melee"));}catch(Exception ex){throw error("type","tipo desconhecido");}
        JsonObject pr=object(j,"projectile");number(pr,"speed",.8,.1,4);integer(pr,"lifetime_ticks",60,1,200);
        return new Move(text(j,"id",""),type,frames,boxes,number(j,"damage",4,0,10000),integer(j,"hitstun",10,0,200),integer(j,"blockstun",6,0,200),number(j,"guard_damage",3,0,100),number(k,"horizontal",.3,0,4),number(k,"vertical",.1,-2,4),bool(k,"launch",false),integer(j,"hitstop",3,0,20),number(cost,"energy",0,0,10000),number(cost,"ultimate",0,0,100),integer(j,"cooldown",0,0,12000),number(gain,"energy_on_hit",3,0,100),number(gain,"ultimate_on_hit",2,0,100),number(gain,"ultimate_on_block",1,0,100),strings(c,"into"),start,end,bool(j,"requires_airborne",false),statuses,j);
    }
    public static Transformation transformation(JsonObject j){header(j);JsonObject s=object(j,"stat_multipliers");return new Transformation(text(j,"id",""),integer(j,"duration_ticks",600,1,12000),number(object(j,"requires"),"ultimate_gauge",100,0,100),number(j,"drain_ultimate_per_sec",4,0,100),number(s,"attack",1.3,.1,10),number(s,"defense",1.1,.1,10),number(s,"speed",1.1,.1,5),number(s,"energy_regen",1,.1,10),refs(object(j,"move_overrides")),integer(object(j,"on_end"),"cooldown_ticks",600,0,12000),j);}
    private Definitions(){}
}
