package com.seunome.clashcraft.client;
import com.google.gson.*;
import com.mojang.blaze3d.platform.InputConstants;
import com.seunome.clashcraft.core.*;
import com.seunome.clashcraft.network.Packets;
import java.util.*;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.*;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;
import static com.seunome.clashcraft.core.Definitions.*;

@EventBusSubscriber(modid="clashcraft",value=Dist.CLIENT)
public final class ClientMod {
    public static final Map<String,Fighter> definitions=new LinkedHashMap<>();
    public static final Map<String,Transformation> transformations=new LinkedHashMap<>();
    public static final Map<UUID,FighterData> states=new HashMap<>();
    private static final EnumMap<Input,KeyMapping> keys=new EnumMap<>(Input.class);
    private static final KeyMapping SELECT=new KeyMapping("key.clashcraft.select",InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_K,"key.categories.clashcraft");
    private static long sequence;private static boolean guardHeld;private static int effectTicks;private static String effect="";
    public static boolean reducedEffects=true;
    @SubscribeEvent public static void register(RegisterKeyMappingsEvent e){int[] codes={GLFW.GLFW_KEY_J,GLFW.GLFW_KEY_U,GLFW.GLFW_KEY_I,GLFW.GLFW_KEY_O,GLFW.GLFW_KEY_P,GLFW.GLFW_KEY_G,GLFW.GLFW_KEY_H,GLFW.GLFW_KEY_V,GLFW.GLFW_KEY_L,GLFW.GLFW_KEY_N,GLFW.GLFW_KEY_R,GLFW.GLFW_KEY_B};Input[] inputs={Input.LIGHT,Input.HEAVY,Input.SPECIAL_1,Input.SPECIAL_2,Input.ULTIMATE,Input.GUARD,Input.DODGE,Input.TRANSFORM,Input.LOCK_ON,Input.ASSIST,Input.TOGGLE,Input.FLY};for(int i=0;i<inputs.length;i++){KeyMapping k=new KeyMapping("key.clashcraft."+inputs[i].name().toLowerCase(Locale.ROOT),InputConstants.Type.KEYSYM,codes[i],"key.categories.clashcraft");keys.put(inputs[i],k);e.register(k);}e.register(SELECT);Packets.receiver=ClientMod::receive;}
    public static FighterData self(){var p=Minecraft.getInstance().player;return p==null?null:states.get(p.getUUID());}
    private static void receive(Packets.Snapshot p){try{switch(p.kind()){case "clear"->{definitions.clear();transformations.clear();states.clear();AvatarRenderer.clear();}case "fighter"->definitions.put(p.key(),fighter(JsonParser.parseString(p.json()).getAsJsonObject()));case "transform"->transformations.put(p.key(),transformation(JsonParser.parseString(p.json()).getAsJsonObject()));case "state"->states.put(UUID.fromString(p.key()),JSON.fromJson(p.json(),FighterData.class));case "fx"->{effect=p.key();effectTicks=effect.equals("ultimate")?30:effect.equals("transform")?40:8;}default->{}}}catch(RuntimeException ex){com.seunome.clashcraft.ClashCraft.LOG.warn("Snapshot inválido: {}",p.kind());}}
    public static void send(Input input,boolean pressed,String value){PacketDistributor.sendToServer(new Packets.Intent(input.ordinal(),pressed,sequence++,value));}
    @SubscribeEvent public static void tick(ClientTickEvent.Post e){Minecraft mc=Minecraft.getInstance();if(mc.player==null||mc.level==null){states.clear();definitions.clear();transformations.clear();AvatarRenderer.clear();guardHeld=false;effectTicks=0;return;}if(effectTicks>0)effectTicks--;FighterData d=self();if(SELECT.consumeClick()&&mc.screen==null)mc.setScreen(new Selection());for(var entry:keys.entrySet()){Input in=entry.getKey();KeyMapping key=entry.getValue();boolean allowed=mc.screen==null&&(in==Input.TOGGLE||(d!=null&&d.enabled));if(in==Input.GUARD){boolean down=allowed&&key.isDown();if(down!=guardHeld){send(in,down,"");guardHeld=down;}while(key.consumeClick()){} }else while(key.consumeClick())if(allowed)send(in,true,"");}if(mc.level.getGameTime()%100==0){Set<UUID> visible=new HashSet<>();mc.level.players().forEach(p->visible.add(p.getUUID()));states.keySet().retainAll(visible);AvatarRenderer.retain(visible);}}
    @SubscribeEvent public static void hud(RenderGuiEvent.Post e){Minecraft mc=Minecraft.getInstance();FighterData d=self();if(d==null||!d.enabled||mc.options.hideGui)return;Fighter f=definitions.get(d.fighter);if(f==null)return;GuiGraphics g=e.getGuiGraphics();int x=12,y=14,w=Math.min(180,g.guiWidth()/3);g.fill(x-4,y-5,x+w+5,y+80,0xb0101726);g.drawString(mc.font,f.name(),x,y,0xfff4d878);y+=13;bar(g,x,y,w,d.health/f.maxHealth(),0xffe75b65,"HP "+(int)d.health+" / "+(int)f.maxHealth());y+=14;bar(g,x,y,w,d.energy/f.maxEnergy(),0xff4bbfe4,"EN "+(int)d.energy);y+=14;bar(g,x,y,w,d.ultimate/100,0xffb27aff,"ULT "+(int)d.ultimate);y+=14;bar(g,x,y,w,d.guard/100,0xffe5c66c,"GUARDA "+(int)d.guard);y+=17;g.drawString(mc.font,d.state+(d.combo>1?"  "+d.combo+" HITS":""),x,y,0xffffffff);y+=12;
        if(d.state.equals("CHARGING"))g.drawCenteredString(mc.font,"CHOQUE | ataque leve! | saldo "+d.clashScore,g.guiWidth()/2,g.guiHeight()/2,0xfff4d878);
        if(!d.statuses.isEmpty()){g.drawString(mc.font,String.join(" ",d.statuses.keySet()).replace("clashcraft:",""),x,y,0xffff9b72);y+=12;}if(!d.cooldowns.isEmpty()){g.drawString(mc.font,"Cooldowns: "+d.cooldowns.size(),x,y,0xffb9bdd0);y+=12;}
        if(d.training){g.drawString(mc.font,"Dano: "+String.format(Locale.ROOT,"%.1f",d.lastDamage)+" | combo: "+String.format(Locale.ROOT,"%.1f",d.comboDamage),x,y,0xffadf2bc);y+=12;g.drawString(mc.font,"S/A/R "+d.startup+"/"+d.active+"/"+d.recovery+" | hit "+d.hitAdvantage+" block "+d.blockAdvantage,x,y,0xffadf2bc);}
        if(!d.target.isEmpty())for(var player:mc.level.players())if(player.getUUID().toString().equals(d.target)){FighterData t=states.get(player.getUUID());Fighter tf=t==null?null:definitions.get(t.fighter);if(tf!=null)bar(g,g.guiWidth()-w-12,28,w,t.health/tf.maxHealth(),0xffe75b65,tf.name());}
        if(effectTicks>0&&(effect.equals("ultimate")||effect.equals("transform"))){g.fill(0,0,g.guiWidth(),10,0xff090b12);g.fill(0,g.guiHeight()-20,g.guiWidth(),g.guiHeight(),0xff090b12);g.drawCenteredString(mc.font,effect.equals("ultimate")?"ULTIMATE":"TRANSFORMAÇÃO",g.guiWidth()/2,g.guiHeight()-15,0xfff4d878);}if(effectTicks>0&&!reducedEffects&&effect.equals("hit"))g.fill(0,0,g.guiWidth(),g.guiHeight(),0x10ffffff);if(d.health<=0)g.drawCenteredString(mc.font,"K.O. — /fighter reset",g.guiWidth()/2,g.guiHeight()/2,0xffff7777);
    }
    @SubscribeEvent public static void hand(RenderHandEvent e){FighterData d=self();if(d!=null&&d.enabled)e.setCanceled(true);}
    private static void bar(GuiGraphics g,int x,int y,int w,double ratio,int color,String label){g.fill(x,y,x+w,y+11,0xff283044);g.fill(x,y,x+(int)(w*FighterData.clamp(ratio,0,1)),y+11,color);g.drawString(Minecraft.getInstance().font,label,x+3,y+1,0xffffffff);}
    private static final class Selection extends Screen {
        private int page;Selection(){super(Component.translatable("screen.clashcraft.select"));}
        @Override protected void init(){List<Fighter> list=new ArrayList<>(definitions.values());int bw=Math.min(150,(width-36)/2),left=width/2-bw-5,top=40;for(int i=page*8;i<Math.min(list.size(),page*8+8);i++){Fighter f=list.get(i);int n=i-page*8;addRenderableWidget(Button.builder(Component.literal(f.name()),b->{send(Input.SELECT,true,f.id());onClose();}).bounds(left+n%2*(bw+10),top+n/2*26,bw,22).build());}if(list.size()>8)addRenderableWidget(Button.builder(Component.literal("Página "+(page+1)),b->{page=(page+1)%((list.size()+7)/8);rebuildWidgets();}).bounds(width/2-65,top+110,130,20).build());addRenderableWidget(Button.builder(Component.literal("Efeitos reduzidos: "+(reducedEffects?"sim":"não")),b->{reducedEffects=!reducedEffects;rebuildWidgets();}).bounds(width/2-100,Math.max(top+136,height-55),200,20).build());addRenderableWidget(Button.builder(Component.translatable("gui.done"),b->onClose()).bounds(width/2-60,Math.max(top+160,height-30),120,20).build());}
        @Override public void render(GuiGraphics g,int mx,int my,float delta){renderBackground(g,mx,my,delta);super.render(g,mx,my,delta);g.drawCenteredString(font,title,width/2,15,0xfff4d878);if(definitions.isEmpty())g.drawCenteredString(font,"Aguardando dados do servidor…",width/2,42,0xffffffff);}
        @Override public boolean isPauseScreen(){return false;}
    }
    private ClientMod(){}
}
