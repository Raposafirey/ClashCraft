package com.seunome.clashcraft.core;

import java.util.*;
import static com.seunome.clashcraft.core.Definitions.*;

/** Estado persistente separado dos controles transitórios da conexão. */
public final class FighterData {
    public String fighter="",state="IDLE",move="",transformation="",target="",animation="idle";
    public double health=100,energy=100,ultimate=0,guard=100,totalDamage=0,lastDamage=0,comboDamage=0;
    public int tick=0,stun=0,hitstop=0,combo=0,maxCombo=0,juggle=0,transformTicks=0,transformCooldown=0,wins=0,losses=0,ultimates=0,coins=0;
    public int startup=0,active=0,recovery=0,hitAdvantage=0,blockAdvantage=0,clashScore=0;
    public boolean enabled=false,flying=false,guarding=false,training=false,infinite=false;
    public Map<String,Integer> cooldowns=new HashMap<>(),statuses=new HashMap<>(),stacks=new HashMap<>();
    public Set<String> unlocked=new HashSet<>(),completedMissions=new HashSet<>();
    public transient Set<String> hitTargets=new HashSet<>();
    public transient ArrayDeque<BufferedInput> buffer=new ArrayDeque<>();
    public transient long lastPacketTick=-1,sequence=-1,lastHitTick=-100,lastSync=-100,guardStarted=0;
    public transient int packets=0,chainIndex=0,airDashes=0;
    public transient String snapshot="",comboTarget="";
    public transient boolean emitted=false;
    public record BufferedInput(Input input,long expires){}
    public void select(Fighter f){fighter=f.id();health=f.maxHealth();energy=f.maxEnergy();ultimate=0;guard=100;enabled=true;training=false;infinite=false;resetAction();transformation="";transformTicks=0;transformCooldown=0;statuses.clear();stacks.clear();cooldowns.clear();target="";flying=false;}
    public void resetAction(){state="IDLE";move="";tick=0;stun=0;hitstop=0;guarding=false;combo=0;juggle=0;chainIndex=0;emitted=false;hitTargets.clear();buffer.clear();}
    public static double clamp(double v,double min,double max){return Double.isFinite(v)?Math.max(min,Math.min(max,v)):min;}
    public void normalize(Fighter f){health=clamp(health,0,f.maxHealth());energy=clamp(energy,0,f.maxEnergy());ultimate=clamp(ultimate,0,100);guard=clamp(guard,0,100);}
    public boolean canAct(){return enabled&&health>0&&stun==0&&hitstop==0&&!statuses.containsKey("clashcraft:stun")&&!statuses.containsKey("clashcraft:freeze");}
    public boolean acceptPacket(long now,long seq){if(seq<=sequence||seq<0)return false;if(lastPacketTick!=now){lastPacketTick=now;packets=0;}if(++packets>16)return false;sequence=seq;return true;}
    public void enqueue(Input in,long now,int ticks){if(buffer.size()>=12)buffer.removeFirst();buffer.addLast(new BufferedInput(in,now+ticks));}
    public void prune(long now){while(!buffer.isEmpty()&&buffer.peekFirst().expires()<now)buffer.removeFirst();}
    public boolean start(Move m,boolean airborne){
        if(!canAct()||(m.airborne()&&!airborne)||cooldowns.getOrDefault(m.id(),0)>0||energy<m.energy()||ultimate<m.ultimate())return false;
        if(statuses.containsKey("clashcraft:silence")&&(m.energy()>0||m.ultimate()>0))return false;
        energy-=m.energy();ultimate-=m.ultimate();move=m.id();tick=0;emitted=false;guarding=false;state=m.type()==MoveType.ultimate?"CASTING_ULTIMATE":"ATTACK";
        startup=m.frames().startup();active=m.frames().active();recovery=m.frames().recovery();hitAdvantage=m.hitstun()-active-recovery;blockAdvantage=m.blockstun()-active-recovery;
        animation=text(object(m.raw(),"presentation"),"animation","attack");hitTargets.clear();if(m.cooldown()>0)cooldowns.put(m.id(),m.cooldown());if(m.type()==MoveType.ultimate)ultimates++;return true;
    }
    public static double damage(double base,double attack,double defense,int hits){return Math.max(0,base)*Math.max(.01,attack)/Math.max(.1,defense)*Math.max(.2,Math.pow(.88,Math.max(0,hits)));}
    public void stepTimers(Fighter f,Transformation t,double regenMultiplier){
        cooldowns.replaceAll((k,v)->v-1);cooldowns.values().removeIf(v->v<=0);statuses.replaceAll((k,v)->v-1);statuses.values().removeIf(v->v<=0);stacks.keySet().retainAll(statuses.keySet());if(transformCooldown>0)transformCooldown--;
        if(transformTicks>0){transformTicks--;ultimate-=t==null?0:t.drain()/20;if(transformTicks==0||ultimate<=0){transformation="";transformTicks=0;transformCooldown=t==null?600:t.cooldown();statuses.put("clashcraft:exhausted",100);}}
        energy+=f.regen()/20*regenMultiplier*(t==null?1:t.regen())*(statuses.containsKey("clashcraft:exhausted")?.5:1);if(!guarding&&stun==0)guard+=.25;
        if(infinite&&training){energy=f.maxEnergy();ultimate=100;guard=100;}normalize(f);
        if(hitstop>0){hitstop--;return;}if(stun>0){stun--;if(stun==0)state="IDLE";}tick++;
    }
    public void restoreTransient(){hitTargets=new HashSet<>();buffer=new ArrayDeque<>();snapshot="";comboTarget="";lastPacketTick=-1;sequence=-1;lastSync=-100;lastHitTick=-100;resetAction();flying=false;target="";training=false;infinite=false;clashScore=0;if(cooldowns==null)cooldowns=new HashMap<>();if(statuses==null)statuses=new HashMap<>();if(stacks==null)stacks=new HashMap<>();if(unlocked==null)unlocked=new HashSet<>();if(completedMissions==null)completedMissions=new HashSet<>();}
}
