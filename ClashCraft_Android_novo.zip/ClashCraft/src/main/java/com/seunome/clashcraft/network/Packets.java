package com.seunome.clashcraft.network;
import java.util.function.Consumer;
import com.seunome.clashcraft.server.GameServer;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.PacketDistributor;
public final class Packets {
    public static Consumer<Snapshot> receiver=p->{};
    public record Intent(int action,boolean pressed,long sequence,String value) implements CustomPacketPayload {
        public static final Type<Intent> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath("clashcraft","intent"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Intent> CODEC=new StreamCodec<>(){public Intent decode(RegistryFriendlyByteBuf b){return new Intent(b.readVarInt(),b.readBoolean(),b.readVarLong(),b.readUtf(160));}public void encode(RegistryFriendlyByteBuf b,Intent p){b.writeVarInt(p.action);b.writeBoolean(p.pressed);b.writeVarLong(p.sequence);b.writeUtf(p.value,160);}};
        public Type<Intent> type(){return TYPE;}
    }
    public record Snapshot(String kind,String key,String json) implements CustomPacketPayload {
        public static final Type<Snapshot> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath("clashcraft","snapshot"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Snapshot> CODEC=new StreamCodec<>(){public Snapshot decode(RegistryFriendlyByteBuf b){return new Snapshot(b.readUtf(16),b.readUtf(160),b.readUtf(32767));}public void encode(RegistryFriendlyByteBuf b,Snapshot p){b.writeUtf(p.kind,16);b.writeUtf(p.key,160);b.writeUtf(p.json,32767);}};
        public Type<Snapshot> type(){return TYPE;}
    }
    public static void register(RegisterPayloadHandlersEvent e){var r=e.registrar("1");r.playToServer(Intent.TYPE,Intent.CODEC,(p,c)->{if(c.player() instanceof ServerPlayer player)GameServer.input(player,p);});r.playToClient(Snapshot.TYPE,Snapshot.CODEC,(p,c)->receiver.accept(p));}
    public static void send(ServerPlayer p,Snapshot packet){PacketDistributor.sendToPlayer(p,packet);}
    private Packets(){}
}
